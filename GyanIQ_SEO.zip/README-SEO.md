# GyanIQ SEO System — Kaise Use Kare

Ye central SEO system hai — **seo-config.json** hi single source of truth hai.

## Naya page/game add karna hai?

1. Apni nayi `.html` file `GyanIQ/` folder mein daal.
2. `seo-config.json` mein `"pages"` ke andar ek naya entry add kar (kisi existing entry ko copy-paste karke badal le):
   ```json
   "NayaGame.html": {
     "title": "Naya Game – Category Name",
     "description": "150-160 characters mein description.",
     "keywords": "keyword1, keyword2, keyword3",
     "robots": "index, follow",
     "schemaType": "WebApplication"
   }
   ```
3. Terminal mein run kar:
   ```
   node build-seo.js
   node generate-sitemap.js
   ```
4. Poora `GyanIQ/` folder Netlify pe drag-drop kar (jaisa normally karta hai).

**Agar step 2 bhool bhi gaya** (config entry add karna), tab bhi koi dikkat nahi —
script automatically default SEO laga dega (title existing `<title>` tag se le lega,
baaki sab `defaults` block se). Bas future mein jab time mile, config mein proper entry
daal dena for better results.

## Login/Signup jaisa private page banaya hai?

Config mein `"robots": "noindex, nofollow"` daal de — automatically sitemap se bhi
bahar ho jayega aur Google index nahi karega.

## Files ka kaam

| File | Kaam |
|---|---|
| `seo-config.json` | Sab SEO data yahi se control hota hai — titles, descriptions, keywords, robots rules, Google Analytics ID |
| `build-seo.js` | Config se real HTML `<head>` mein meta tags/schema/GA/H1 inject karta hai |
| `generate-sitemap.js` | Config se `sitemap.xml` banata hai (noindex pages khud-ba-khud exclude) |
| `GyanIQ/robots.txt` | Google ko batata hai kya crawl karna hai, sitemap ka link deta hai |
| `GyanIQ/_redirects` | Netlify ko batata hai ki `gyaniq.netlify.app` ke saare requests `gyaniq.in` pe 301-redirect ho jayein (duplicate content se bachne ke liye) |
| `GyanIQ/404.html` | Custom 404 error page, site ke design se match karta hai, noindex hai |
| `GyanIQ/assets/og-image.png` | WhatsApp/Facebook share preview image |

## Zaroori: Ye script dono kab chalani hai

Har baar jab:
- Naya page/game add kare
- Kisi existing page ka title/description badalna ho
- `seo-config.json` mein kuch bhi change kare

**dono commands zaroor chalana:**
```
node build-seo.js
node generate-sitemap.js
```
Phir Netlify pe upload karna.

## Ye system kya NAHI karta (limitations)

- Ye ek **build-time script** hai, runtime JS nahi — matlab tujhe upload se
  **pehle** ye commands chalane hain. Agar bhool gaya, purani SEO tags hi
  rahengi, naya page bhi properly cover ho jayega (default fallback ki wajah se)
  lekin best results ke liye config entry add karna better hai.
- Leaderboard page ka data real-time badalta rehta hai (Supabase se), isliye
  uska meta description generic/static rakha hai — ye normal hai, aisi
  pages ke liye yahi best practice hai.
- Og image abhi placeholder path (`/assets/og-image.png`) use kar raha hai —
  agar ye image actually exist nahi karti site pe, toh WhatsApp/Facebook share
  preview mein image nahi dikhega. Ek 1200x630px image bana ke us path pe
  daal dena.

## Baaki manual steps (mujhse nahi ho sakte)

1. ✅ ~~Google Search Console verify + sitemap submit~~ — **ho chuka hai**
2. ✅ ~~Google Analytics~~ — **ho chuka hai** (G-8NYSKTGJG9)
3. Netlify pe naya `GyanIQ/` folder (isi ZIP se) upload/redeploy karna — **ye bacha hai**
4. Netlify Domain settings mein confirm kar lena ki `gyaniq.netlify.app` bhi is hi site se attached hai (taaki `_redirects` wala rule kaam kare)
