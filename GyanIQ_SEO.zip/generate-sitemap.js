/*
  GyanIQ Sitemap Generator
  --------------------------
  Reads seo-config.json and writes GyanIQ/sitemap.xml automatically.

  Rules it follows:
  - index.html is written as the root URL (https://gyaniq.in/), never as
    /index.html, to avoid duplicate-content issues.
  - Any page with "robots": "noindex..." (e.g. login.html, signup.html) is
    excluded automatically - you never need to remember to exclude it by hand.
  - Any future page added to seo-config.json is picked up automatically.

  Run: node generate-sitemap.js
  (Run this together with build-seo.js whenever pages are added/changed.)
*/

const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const config = JSON.parse(fs.readFileSync(path.join(ROOT, 'seo-config.json'), 'utf8'));
const { site, pages } = config;
const today = new Date().toISOString().split('T')[0];

// Optional per-page overrides for priority/changefreq. Anything not listed
// here falls back to a sensible default.
const PRIORITY_OVERRIDES = {
  'index.html': { priority: '1.0', changefreq: 'daily' },
  'games.html': { priority: '0.9', changefreq: 'weekly' },
  'tournaments.html': { priority: '0.8', changefreq: 'daily' },
  'leaderboard.html': { priority: '0.8', changefreq: 'always' },
  'contact.html': { priority: '0.5', changefreq: 'monthly' },
  'help.html': { priority: '0.5', changefreq: 'monthly' },
};
const DEFAULT_PRIORITY = { priority: '0.8', changefreq: 'weekly' };

const urls = [];

Object.entries(pages).forEach(([filename, pageCfg]) => {
  const robots = pageCfg.robots || config.defaults.robots;
  if (robots.startsWith('noindex')) return; // skip private pages

  const loc = filename === 'index.html'
    ? `${site.domain}/`
    : `${site.domain}/${filename}`;

  const { priority, changefreq } = PRIORITY_OVERRIDES[filename] || DEFAULT_PRIORITY;
  urls.push({ loc, priority, changefreq });
});

const xmlLines = [
  '<?xml version="1.0" encoding="UTF-8"?>',
  '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
  ...urls.flatMap(u => [
    '  <url>',
    `    <loc>${u.loc}</loc>`,
    `    <lastmod>${today}</lastmod>`,
    `    <changefreq>${u.changefreq}</changefreq>`,
    `    <priority>${u.priority}</priority>`,
    '  </url>',
  ]),
  '</urlset>',
];

fs.writeFileSync(path.join(ROOT, 'GyanIQ', 'sitemap.xml'), xmlLines.join('\n') + '\n', 'utf8');
console.log(`sitemap.xml written with ${urls.length} URLs (excluded noindex pages automatically).`);
